#!/bin/sh
# VOS Security IP login Shell Powered By 80uncle
#
atime=`date "+%Y-%m-%d==%H:%M:%S"`
croniptab=/etc/cron.daily/iptab
iptables=/etc/sysconfig/iptables
iptabbak=/etc/sysconfig/iptables.bak
iptabvos=/etc/sysconfig/iptables_vos

grep -v "#" /etc/ssh/sshd_config |grep Port|awk '{print $2}' > /root/abc
sshport=`cat /root/abc`
# ssh port > /root/abc

cd /etc/sysconfig/

touch $iptabvos
wget http://download.80uncle.com/VOS/VOS_Secure_shell/iptables.bak
chmod 600 $iptabvos && chown root.root $iptabvos
chmod 600 $iptabbak && chown root.root $iptabbak
sleep 1
sed -i -e "33a -A RH-Firewall-1-INPUT -p tcp -m state --state NEW -m tcp --dport $sshport -j ACCEPT" /etc/sysconfig/iptables.bak
# download iptables and iptabbak && add iptabvos file

if [ -f "$iptables" ]; then  
mv iptables iptables-$atime
else
wget http://download.80uncle.com/VOS/VOS_Secure_shell/iptables
chmod 600 $iptables && chown root.root $iptables
fi

cat /etc/sysconfig/iptables.bak > /etc/sysconfig/iptables
/sbin/service iptables restart >/dev/null
chown root.root /etc/sysconfig/iptables*
# add ssh port to iptables

cd /etc/cron.daily/

if [ ! -f "$croniptab" ]; then  
wget http://download.80uncle.com/VOS/VOS_Secure_shell/iptab
chmod 755 $croniptab && chown root.root $croniptab
fi
# if croniptab shell

mkdir -p /data
cd /data
#wget http://download.80uncle.com/VOS/VOS_Secure_shell/vos_login
#chmod 755 ./vos_login
#/data/vos_login
#####################################################################
#wget http://download.80uncle.com/Other/shc-3.8.3.tar.gz
#tar zxvf shc-3.8.3.tar.gz
#cd shc-3.8.3
#mkdir -p /usr/local/man/man1/
#make
#yes|make install 
#cd ..
#### shell hash ####
#shc -r -f ./vos_login
#rm -fr ./vos_login.x.c
#rm -fr ./vos_login
#mv ./vos_login.x ./vos_login
#### after hash shell ####
### 下载 web 端安全使用
wget http://download.80uncle.com/VOS/VOS_Secure_shell/web_vos_safe.sh
chmod 755 web_vos_safe.sh && ./web_vos_safe.sh

sleep 3
rm -fr /root/abc
rm -fr /data/web_vos_safe.sh
iptables -L -n
