#!/bin/sh
# install http php
path=/var/www/html
yum -y install httpd httpd-devel php php-common php-mbstring php-gd php-imap php-ldap php-odbc php-pear php-xml php-xmlrpc

touch /etc/sysconfig/.loginIP.txt && chmod 646 /etc/sysconfig/.loginIP.txt
touch /etc/sysconfig/.badip.txt && chmod 646 /etc/sysconfig/.badip.txt

cd /etc/httpd/conf/
mv httpd.conf httpd.confbak
wget http://download.80uncle.com/VOS/VOS_Secure_shell/httpd.conf
chown root.root httpd.conf && chmod 644 httpd.conf

cd /etc/
mv php.ini php.inibak
wget http://download.80uncle.com/VOS/VOS_Secure_shell/php.ini
chown root.root /etc/php.ini && chmod 644 /etc/php.ini
/sbin/service httpd start

# if webroot
if [ ! -d "$path" ]; then
mkdir -p $path
chmod 755 $path && chown root.root $path
fi

# download web file
cd /var/www/html/
useradd -M -s /sbin/nologin www
chown www.www /var/www/html/
wget http://download.80uncle.com/VOS/VOS_Secure_shell/voip_web.tar.gz
tar -zxvf voip_web.tar.gz
chmod 700 /var/www/html/.VOIP_SF/nat
chmod 700 /var/www/html/.VOIP_SF/ip_ddos
rm -fr voip_web.tar.gz

